Started from rev09, added forceUpdate line to LOVEMODE in order to prevent flickering.  If this doesn't work, go back to rev09 and call it good.

I WAS WRONG.  FORCEUPDATE IS JUST A WAY TO FORCE THE SCREEN TO UPDATE AFTER A NEW MODE IS CHOSEN BY THE MODE BUTTON.  FLICKER WAS CAUSED BY TRYING TO FADE THE LEDS IN LOVE MODE.  FIXED.