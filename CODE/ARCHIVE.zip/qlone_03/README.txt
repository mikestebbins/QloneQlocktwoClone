starting from qlone_02

added in code from qlone_mike

created new mode (last in list) that alternates with delay between Mike & Em and heart outline
        
        
