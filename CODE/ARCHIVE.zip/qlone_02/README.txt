starting from original downloaded code
added photocell light changing ability
Button 4 now worthless (commented out)
